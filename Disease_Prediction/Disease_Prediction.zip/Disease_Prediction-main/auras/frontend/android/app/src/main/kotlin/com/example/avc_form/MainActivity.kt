package com.example.avc_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
