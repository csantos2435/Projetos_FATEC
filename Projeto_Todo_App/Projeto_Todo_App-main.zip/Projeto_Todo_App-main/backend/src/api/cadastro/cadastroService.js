const Cadastro = require('./cadastro')

Cadastro.methods(['get', 'post', 'delete'])

module.exports = Cadastro