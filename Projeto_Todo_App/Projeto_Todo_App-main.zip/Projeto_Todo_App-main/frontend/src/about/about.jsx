import React from "react";
import PageHeader from "../template/pageHeader";

export default props => (
    <div>
        <PageHeader name='Sobre' small='Nós'></PageHeader>
        <h2>Nome</h2>
        <p>Camilli Ramos dos Santos</p>
        <h2>Curso</h2>
        <p>2º Semestre</p>
        <p>DSM - Desenvolvimento de Software e Multiplataforma</p>
    </div>
);